package ua.lviv.iot.repair.model;

public class AbstractMaterials {
    protected String materialsBrand;
    protected String materialsColor;
    protected double priceInUAH;
    protected double materialSize;
    protected String companyOfManufactotures;
    protected boolean neededForSockets;

    public String getMaterialsBrand(){
        return materialsBrand;
    }

    public void setMaterialsBrand(String materialsBrand) {
        this.materialsBrand = materialsBrand;
    }


    public String getMaterialsColor(){
        return materialsColor;
    }

    public void setMaterialsColor(String materialsColor ) {
        this.materialsColor = materialsColor;
    }

    public double getPriceInUAH() {
        return priceInUAH;
    }

    public void setPriceInUAH(double priceInUAH) {
        this.priceInUAH = priceInUAH;
    }

    public double getMaterialSize() {
        return materialSize;
    }

    public void setMaterialSize(double materialSize) {
        this.materialSize = materialSize;
    }

    public String getCompanyOfManufactotures(){
        return companyOfManufactotures;
    }
    public void setCompanyOfManufactotures(String companyOfManufactotures) {
        this.companyOfManufactotures = companyOfManufactotures;
    }
    public Boolean getNeededForSockets() {
        return neededForSockets;
    }

    public void setNeededForSockets(boolean neededForSockets) {
        this.neededForSockets = neededForSockets;
    }

    public  AbstractMaterials(String materialsBrand,String materialsColor,double priceInUAH,double materialSize,String companyOfManufactotures,boolean neededForSockets){
        super();

        this.materialsBrand=materialsBrand;
        this.materialsColor=materialsColor;
        this.priceInUAH=priceInUAH;
        this.materialSize=materialSize;
        this.companyOfManufactotures=companyOfManufactotures;
        this.neededForSockets=neededForSockets;
    }

}
