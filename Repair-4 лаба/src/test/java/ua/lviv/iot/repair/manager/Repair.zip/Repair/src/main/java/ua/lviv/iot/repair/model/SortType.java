package ua.lviv.iot.repair.model;

public enum SortType {
    ASCENDING,DESCENDING
}
