package ua.lviv.iot.repair.manager;

import ua.lviv.iot.repair.model.AbstractMaterials;

import java.util.ArrayList;

public class MaterialsMaterials {
    private ArrayList<AbstractMaterials> materials = new ArrayList<AbstractMaterials>();
    public void addMaterial(AbstractMaterials material){
        materials.add(material);
    }

    public ArrayList<AbstractMaterials> findMaterialsByPrice(ArrayList<AbstractMaterials> materials,double priceInUAH){
        ArrayList<AbstractMaterials> foundMaterials=new ArrayList<AbstractMaterials>();
        for(AbstractMaterials material:materials){
            if(material.getPriceInUAH()==priceInUAH){
                foundMaterials.add(material);
            }
        }
        return foundMaterials;
    }

    public ArrayList<AbstractMaterials> findMaterialsByColor(ArrayList<AbstractMaterials> materials, String materialsColor){
        ArrayList<AbstractMaterials> foundMaterials=new ArrayList<AbstractMaterials>();
        for(AbstractMaterials material:materials){
            if(material.getMaterialsColor().contains(materialsColor)){
                foundMaterials.add(material);
            }
        }
        return foundMaterials;
    }


}
