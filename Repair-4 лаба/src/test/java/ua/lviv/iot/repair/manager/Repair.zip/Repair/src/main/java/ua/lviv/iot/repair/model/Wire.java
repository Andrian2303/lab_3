package ua.lviv.iot.repair.model;

public class Wire extends AbstractMaterials {
    protected TypeOfWire typeOfWire;

    public TypeOfWire getTypeOfWire() {
        return typeOfWire;
    }

    public Wire(String materialsBrand,String materialsColor,double priceInUAH,double materialSize,String companyOfManufactotures,boolean neededForSockets, TypeOfWire typeOfWire){
        super(materialsBrand,materialsColor,priceInUAH,materialSize,companyOfManufactotures,neededForSockets);
        this.typeOfWire=typeOfWire;
    }
}
