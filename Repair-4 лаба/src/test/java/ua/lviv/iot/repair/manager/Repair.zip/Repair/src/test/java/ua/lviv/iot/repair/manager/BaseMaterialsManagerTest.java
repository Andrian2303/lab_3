package ua.lviv.iot.repair.manager;

public class BaseMaterialsManagerTest {
}
