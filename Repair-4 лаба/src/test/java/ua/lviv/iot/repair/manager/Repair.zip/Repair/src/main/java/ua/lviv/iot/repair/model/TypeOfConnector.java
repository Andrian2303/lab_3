package ua.lviv.iot.repair.model;

public enum TypeOfConnector {
    TYPE_A_AMERICAN,TYPE_C_EUROPEAN,TYPE_G_BRITANIAN,TYPE_L_ITALIAN

}
