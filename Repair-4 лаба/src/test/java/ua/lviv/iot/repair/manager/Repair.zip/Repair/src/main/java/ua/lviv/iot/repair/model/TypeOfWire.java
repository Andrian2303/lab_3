package ua.lviv.iot.repair.model;

public enum TypeOfWire {
    SINGLE_CORE_WIRE,MULTI_WIRE,ALUMINIUM_WIRE
}
