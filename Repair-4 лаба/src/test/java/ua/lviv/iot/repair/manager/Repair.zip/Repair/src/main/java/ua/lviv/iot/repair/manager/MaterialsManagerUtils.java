package ua.lviv.iot.repair.manager;

import ua.lviv.iot.repair.model.AbstractMaterials;
import ua.lviv.iot.repair.model.SortType;

import java.util.List;

public class MaterialsManagerUtils {
    public static List<AbstractMaterials> sortMateralsForSocketByPrice(List<AbstractMaterials> materials, SortType sortType) {
        if (sortType == SortType.ASCENDING) {

        } else {
        }
        return null;
    }

    public static List<AbstractMaterials> sortMaterialsByCompanyOfManufecturer(List<AbstractMaterials> materials, SortType sortType) {
        if (sortType == SortType.ASCENDING) {
        } else {
        }
        return null;
    }
}